ALTER TABLE usuproyecto
ADD ip varchar(16);

ALTER TABLE usuproyecto
ADD rol varchar(15);

ALTER TABLE usuproyecto
ADD ultimo_acceso varchar(60);
