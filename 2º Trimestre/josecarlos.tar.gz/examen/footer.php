

<footer class="blockquote-footer fixed-bottom">
<br>
<?php echo "Está usted conectado como: " . $_SESSION['usuario']; ?> <br>   
<?php echo "La ultima conexión fue: " . $_SESSION['fecha']; ?> <br>  
<?php echo "Dirección última conexión: " . $_SESSION['ip']; ?> <br>   

Gestión de incidencias del <a href="https://iesamachado.org" target="_blank">IES Antonio Machado</a>. Desarrollado por Pepe, Antonio Manuel y Juan</footer>
</body>
</html>