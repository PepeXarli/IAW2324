create table latabla (
    id varchar(2) primary key,
    username varchar(20),
    a varchar(20),
    apellidos varchar(20),
    email varchar(20),
    telefono varchar(20),
    password varchar(20),
    rol varchar(20)
);